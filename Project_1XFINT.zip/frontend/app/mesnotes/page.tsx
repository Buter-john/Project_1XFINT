"use client";

import ListeNotesFrais from "../component/ListeNotesFrais";
import Barrelayout from "../component/Barrelayout";

const Mesnote = () => {
  return (
    <Barrelayout>
      <ListeNotesFrais mine />
    </Barrelayout>
  );
};

export default Mesnote;